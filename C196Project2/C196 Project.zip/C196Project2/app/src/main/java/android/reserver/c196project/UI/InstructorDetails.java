package android.reserver.c196project.UI;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.reserver.c196project.R;

public class InstructorDetails extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_instructor_details);
    }
}